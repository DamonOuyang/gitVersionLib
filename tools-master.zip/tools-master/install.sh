#!/bin/bash

cp .vimrc     ~/
cp .gitconfig ~/
cp pull.sh status.sh ../
chmod +x ~/wd/pull.sh 
chmod +x ~/wd/status.sh 

