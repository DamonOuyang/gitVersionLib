#ifndef target_h

#ifdef WIN32
	typedef unsigned char	BYTE;
	typedef unsigned short	WORD;
	typedef unsigned long	DWORD;
	typedef int				BOOL;

	typedef long			LONG;
	typedef unsigned long	ULONG;
	typedef short			COUNT;
	typedef unsigned short	UCOUNT;
	typedef unsigned char	byte;

	#define NO_ERROR		0
	#define SOME_ERROR		(~0)

	#include <memory.h>
	#include <string.h>
	#include <stdlib.h>
	#include <time.h>

#endif

	
#include "bostypes.h"
#include "msg.h"

#include "remio.h"
#include "session.h"
#include "serial.h"
#include "bosopn.h"

#define target_h        
#endif
