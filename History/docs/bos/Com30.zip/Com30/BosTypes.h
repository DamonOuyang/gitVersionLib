#ifndef bostypes_h

#define MTYPE_OFS  8
typedef struct OpnHdr {
	LONG        ProjectNr;
	LONG        MachNr;
	COUNT       MachType;
	LONG        OpnNr;
	ULONG       Start;
	ULONG       End;
//	LONG        Cnf;
//	COUNT       CnfVers;
} OPNHDR;
typedef OPNHDR  *pOPNHDR;
#define XHDR    {  8, 4, 4, 2, 4, 4, 4, 4, 2 }

typedef struct OpnOmz {
	LONG        OmzGrp;
	LONG        ArtNr;
	LONG        ExplPrijs;
	LONG        VerkPrijs;
	COUNT       Perc;
	LONG        Aant;
	LONG        Verbruik;
	LONG        BedrExpl;
	LONG        BedrVerk;
} OPNOMZ;
typedef OPNOMZ  *pOPNOMZ;
#define XOMZ    {  9, 4, 4, 4, 4, 2, 4, 4, 4, 4 }

#define OMZ_EXPLPRIJS   0x0004L
#define OMZ_VERBRUIK    0x0040L
#define OMZ_BEDREXPL    0x0080L


typedef struct OpnTrn {
	LONG        TrnGrp;
	COUNT       PayMeth;
	LONG        AantVerk;
	LONG        BedrVerk;
	LONG        AantOpw;
	LONG        BedrOpw;
//	LONG        AantNeg;
//	LONG        BedrNeg;
} OPNTRN;
typedef OPNTRN  *pOPNTRN;
#define XTRN    {  8, 4, 2, 4, 4, 4, 4, 4, 4 }


typedef struct OpnOpr {
	LONG        Operator;
	COUNT       PayMeth;
	LONG        AantVerk;
	LONG        BedrVerk;
	LONG        AantOpw;
	LONG        BedrOpw;
	LONG        AantNeg;
	LONG        BedrNeg;
} OPNOPR;
typedef OPNOPR  *pOPNOPR;
#define XOPR    {  8, 4, 2, 4, 4, 4, 4, 4, 4 }


typedef struct OpnBtw {
	LONG        OmzGrp;
	LONG        TrnGrp;
	COUNT       Perc;
	LONG        BedrExpl;
	LONG        BedrVerk;
} OPNBTW;
typedef OPNBTW  *pOPNBTW;
#define XBTW    {  5, 4, 4, 2, 4, 4 }

#define BTW_BEDREXPL    0x0008L

typedef struct OpnCash {
	LONG        CoinNr;
	LONG        AantInKas;
	LONG        BedrInKas;
	LONG        AantInMM;
	LONG        BedrInMM;
	LONG        AantUit;
	LONG        BedrUit;
	LONG        AantInvest;
	LONG        BedrInvest;
	LONG        AantAktueel;
	LONG        BedrAktueel;
} OPNCASH;
typedef OPNCASH  *pOPNCASH;
#define XCASH    {  11, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4 }


typedef struct OpnAKrt {
	LONG        BdgtNr;
	LONG        KrtNr;
//	ULONG       Stamp;
	UCOUNT      TrnNr;
	LONG        BedrVerk;
//	LONG        BedrOpw;
//	LONG        BedrNeg;
	LONG        Saldo;
} OPNAKRT;
typedef OPNAKRT  *pOPNAKRT;
#define XAKRT    {  8, 4, 4, 4, 2, 4, 4, 4, 4 }


typedef struct OpnPKrt {
//	LONG        PrsNr;
	LONG        KrtNr;
	ULONG       Stamp;
//	UCOUNT      TrnNr;
//	LONG        BedrVerk;
//	LONG        BedrOpw;
//	LONG        BedrNeg;
	LONG        Saldo;
} OPNPKRT;
typedef OPNPKRT  *pOPNPKRT;
#define XPKRT    {  8, 4, 4, 4, 2, 4, 4, 4, 4 }


typedef struct OpnKey {
	COUNT       KeyType;
	LONG        KeyNr;
	ULONG       Stamp;
} OPNKEY;
typedef OPNKEY  *pOPNKEY;
#define XKEY    {  3, 2, 4, 4 }


typedef struct OpnCnt {
	LONG        Counter;
} OPNCNT;
typedef OPNCNT  *pOPNCNT;
#define XCNT    {  1, 4 }


#define HDR    0
#define OMZ    1
#define TRN    2
#define OPR    3
#define BTW    4
#define CASH   5
#define AKRT   6
#define PKRT   7
#define KEY    8
#define CNT    9
#define BIN28  10
#define EVT    11
#define ERR    12
#define VIS    13
#define NONE   14

#define MTYPE_AUT    10
#define MTYPE_BSU    11
#define MTYPE_KAS    12

#define MTYPE_BSU28  20
#define MTYPE_AUT28  21
#define MTYPE_KAS28  22
#define MTYPE_PIN28  23

#define bostypes_h
#endif
