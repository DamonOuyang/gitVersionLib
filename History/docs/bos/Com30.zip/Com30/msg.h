#ifndef msh_h

struct find_t {
	char reserved[21];
	char attrib;
	WORD wr_time;
	WORD wr_date;
	long size;
	char name[13];
};

typedef struct find_t  INFO;
typedef INFO           *pINFO;


//struct dosdate_t {
//	unsigned char day;			/* 1-31 */
//	unsigned char month;		/* 1-12 */
//	unsigned short year;		/* 1980-2099 */
//	unsigned char dayofweek;	/* 0-6, 0=Sunday */
//};
//
//struct dostime_t {
//	unsigned char hour;			/* 0-23 */
//	unsigned char minute;		/* 0-59 */
//	unsigned char second;		/* 0-59 */
//	unsigned char hsecond;		/* 0-99 */
//};


#define MAX_FILNAM    64

#ifdef WIN32
	#pragma pack(push, 1)
#endif


typedef struct TxGetDate {
  WORD   Func;      // 0x2A00
} TX_GETDATE;
typedef TX_GETDATE *pTX_GETDATE;

typedef struct RxGetDate {
  WORD   Func;      // 0x2A00
  WORD   Error;     // error
  WORD   Year;
  BYTE   Month;
  BYTE   Day;
} RX_GETDATE;
typedef RX_GETDATE *pRX_GETDATE;


typedef struct TxSetDate {
  WORD   Func;      // 0x2B00
  WORD   Year;
  BYTE   Month;
  BYTE   Day;
} TX_SETDATE;
typedef TX_SETDATE *pTX_SETDATE;

typedef struct RxSetDate {
  WORD   Func;      // 0x2B00
  WORD   Error;     // error
} RX_SETDATE;
typedef RX_SETDATE *pRX_SETDATE;


typedef struct TxGetTime {
  WORD   Func;      // 0x2C00
} TX_GETTIME;
typedef TX_GETTIME *pTX_GETTIME;

typedef struct RxGetTime {
  WORD   Func;      // 0x2C00
  WORD   Error;     // error
  BYTE   Hours;
  BYTE   Minutes;
  BYTE   Seconds;
  BYTE   cSecs;
} RX_GETTIME;
typedef RX_GETTIME *pRX_GETTIME;


typedef struct TxSetTime {
  WORD   Func;      // 0x2D00
  BYTE   Hours;
  BYTE   Minutes;
  BYTE   Seconds;
  BYTE   cSecs;
} TX_SETTIME;
typedef TX_SETTIME *pTX_SETTIME;

typedef struct RxSetTime {
  WORD   Func;      // 0x2D00
  WORD   Error;     // error
} RX_SETTIME;
typedef RX_SETTIME *pRX_SETTIME;


#define CMPOPEN_RDONLY    0x00
#define CMPOPEN_RDWR      0x02
#define CMPOPEN_APPEND    0x03
#define CMPOPEN_FIXED     0x04

#define DOSOPEN_RDONLY    (O_RDONLY + SH_DENYRW)
#define DOSOPEN_RDWR      (O_RDWR   + SH_DENYRW)
#define DOSOPEN_APPEND    (O_APPEND + SH_DENYRW)

typedef struct TxFOpen {
  BYTE   Mode;      // Access, Share
  BYTE   Func;      // 0x3D
  char   Name[1];   // Asciiz string 
} TX_FOPEN;
typedef TX_FOPEN *pTX_FOPEN;

typedef struct RxFOpen {
  WORD   Func;      // 0x3Dxx
  WORD   Error;     // error
  WORD   hFile;     // filehandle
} RX_FOPEN;
typedef RX_FOPEN *pRX_FOPEN;


typedef struct TxFClose {
  WORD   Func;      // 0x3E00
  WORD   hFile;     // filehandle
} TX_FCLOSE;
typedef TX_FCLOSE *pTX_FCLOSE;

typedef struct RxFClose {
  WORD   Func;      // 0x3E00
  WORD   Error;     // error
} RX_FCLOSE;
typedef RX_FCLOSE *pRX_FCLOSE;


typedef struct TxFRead {
  WORD   Func;      // 0x3F00
  WORD   hFile;     // filehandle
  WORD   Bufsize;   // buffer size
} TX_FREAD;
typedef TX_FREAD *pTX_FREAD;

typedef struct RxFRead {
  WORD   Func;      // 0x3F00
  WORD   Error;     // error
  WORD   Count;     // nRead
  BYTE   dta[1];
} RX_FREAD;
typedef RX_FREAD *pRX_FREAD;


typedef struct TxFWrite {
  WORD   Func;      // 0x4000
  WORD   hFile;     // filehandle
  WORD   Bufsize;   // buffer size
  BYTE   dta[1];
} TX_FWRITE;
typedef TX_FWRITE *pTX_FWRITE;

typedef struct RxFWrite {
  WORD   Func;      // 0x4000
  WORD   Error;     // error
  WORD   Count;     // nWritten
} RX_FWRITE;
typedef RX_FWRITE *pRX_FWRITE;


typedef struct TxFDelete {
  WORD   Func;      // 0x4100
  char   Name[1];   // Asciiz string 
} TX_FDELETE;
typedef TX_FDELETE *pTX_FDELETE;

typedef struct RxFDelete {
  WORD   Func;      // 0x4100
  WORD   Error;     // error
} RX_FDELETE;
typedef RX_FDELETE *pRX_FDELETE;


typedef struct TxFSeek {
  BYTE   Method;    // relative to (0 = BOF, 1 = CurPos, 2 = EOF)
  BYTE   Func;      // 0x42
  WORD   hFile;     // filehandle
  long   Offset;    // offset;
} TX_FSEEK;
typedef TX_FSEEK *pTX_FSEEK;

typedef struct RxFSeek {
  WORD   Func;      // 0x42xx
  WORD   Error;     // error
  DWORD  Pos;       // current position
} RX_FSEEK;
typedef RX_FSEEK *pRX_FSEEK;


typedef struct TxFirst {
  WORD   Func;          // 0x4E00
  WORD   Attrib;
  char   FName[1];      // Asciiz string
} TX_FIRST;
typedef TX_FIRST *pTX_FIRST;

typedef struct RxFirst {
  WORD   Func;          // 0x4E00
  WORD   Error;         // error
  BYTE   Reserved[21];
  BYTE   Attrib;
  WORD   Time;
  WORD   Date;
  DWORD  Size;
  char   NameExt[13];   // Asciiz string
} RX_FIRST;
typedef RX_FIRST *pRX_FIRST;


typedef struct TxNext {
  WORD   Func;          // 0x4F00
  WORD   Filler;
  BYTE   Reserved[21];
} TX_NEXT;
typedef TX_NEXT *pTX_NEXT;

typedef struct RxNext {
  WORD   Func;          // 0x4F00
  WORD   Error;         // error
  BYTE   Reserved[21];
  BYTE   Attrib;
  WORD   Time;
  WORD   Date;
  DWORD  Size;
  char   NameExt[13];   // Asciiz string
} RX_NEXT;
typedef RX_NEXT *pRX_NEXT;


typedef struct TxFRename {
  WORD   Func;      // 0x5600
  char   OldName[13];
  char   NewName[13];
} TX_FRENAME;
typedef TX_FRENAME *pTX_FRENAME;

typedef struct RxFRename {
  WORD   Func;      // 0x5600
  WORD   Error;     // error
} RX_FRENAME;
typedef RX_FRENAME *pRX_FRENAME;


#define FCREATE_FLASH   0x01
#define FCREATE_FIXED   0x02
#define FCREATE_SHADOW  0x04

#define FCREATE_ACC0    0x00
#define FCREATE_ACC1    0x08
#define FCREATE_ACC2    0x10
#define FCREATE_ACC3    0x18

typedef struct TxFCreate {
  WORD   Func;      // 0x5B00
  WORD   Size;
  BYTE   Attrib;    // Attributes
  char   Name[1];   // Asciiz string 
} TX_FCREATE;
typedef TX_FCREATE *pTX_FCREATE;

typedef struct RxFCreate {
  WORD   Func;      // 0x5B00
  WORD   Error;     // error
  WORD   hFile;     // filehandle
} RX_FCREATE;
typedef RX_FCREATE *pRX_FCREATE;


typedef struct TxFCommit {
  WORD   Func;      // 0x6800
  WORD   hFile;     // filehandle
} TX_FCOMMIT;
typedef TX_FCOMMIT *pTX_FCOMMIT;

typedef struct RxFCommit {
  WORD   Func;      // 0x6800
  WORD   Error;     // error
} RX_FCOMMIT;
typedef RX_FCOMMIT *pRX_FCOMMIT;


typedef struct TxConnect {
  WORD   Func;      // 0xFF00
  DWORD  ProjectNr; // Projectnummer
  DWORD  SubPrjct;  // SubProjectID (meerdere DCT's per project)
  WORD   Access;    // Aanvullend Access control
  WORD   SrcDst;    // Source Destination identificatie
} TX_CONNECT;
typedef TX_CONNECT *pTX_CONNECT;

typedef struct RxConnect {
  WORD   Func;      // 0xFF00
  WORD   Error;
  DWORD  ProjectNr; // Projectnummer
  DWORD  SubPrjct;  // SubProjectID (meerdere DCT's per project)
  WORD   Access;    // Aanvullend Access control
  WORD   SrcDst;    // Source Destination identificatie
} RX_CONNECT;
typedef RX_CONNECT *pRX_CONNECT;


typedef struct TxDisconnect {
  WORD   Func;      // 0xFF01
} TX_DISCONNECT;
typedef TX_DISCONNECT *pTX_DISCONNECT;

typedef struct RxDisonnect {
  WORD   Func;      // 0xFF01
  WORD   Error;
} RX_DISCONNECT;
typedef RX_DISCONNECT *pRX_DISCONNECT;


typedef struct TxAbort {
  WORD   Func;      // 0xFF02
} TX_ABORT;
typedef TX_ABORT *pTX_ABORT;

typedef struct RxAbort {
  WORD   Func;      // 0xFF02
  WORD   Error;
} RX_ABORT;
typedef RX_ABORT *pRX_ABORT;


typedef struct TxXCount {
  WORD   Func;      // 0xFF03
  DWORD  Count;
} TX_XCOUNT;
typedef TX_XCOUNT *pTX_XCOUNT;

typedef struct RxXCount {
  WORD   Func;      // 0xFF03
  WORD   Error;
  DWORD  Count;
} RX_XCOUNT;
typedef RX_XCOUNT *pRX_XCOUNT;


typedef struct TxPrefix {
  WORD   Func;      // 0xXXXX
} TX_PREFIX;
typedef TX_PREFIX *pTX_PREFIX;

typedef struct RxPrefix {
  WORD   Func;      // 0xXXXX
  WORD   Error;
} RX_PREFIX;
typedef RX_PREFIX *pRX_PREFIX;


#define FN_GETDATE   0x2A00
#define FN_SETDATE   0x2B00
#define FN_GETTIME   0x2C00
#define FN_SETTIME   0x2D00

#define FN_OPEN      0x3D00
#define FN_CLOSE     0x3E00
#define FN_READ      0x3F00
#define FN_WRITE     0x4000
#define FN_DELETE    0x4100
#define FN_SEEK      0x4200
#define FN_FIRST     0x4E00
#define FN_NEXT      0x4F00
#define FN_RENAME    0x5600
#define FN_CREATE    0x5B00
#define FN_COMMIT    0x6800

#define CMD_CONNECT     0xFF00
#define CMD_DISCONNECT  0xFF01
#define CMD_ABORT       0xFF02
#define CMD_XCOUNT      0xFF03

#ifdef WIN32
	#pragma pack(pop)
#endif

#define msg_h
#endif
