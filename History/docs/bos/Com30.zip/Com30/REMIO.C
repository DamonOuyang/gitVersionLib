#include "target.h"

static BYTE	cmdbuf[256];
static BYTE	rspbuf[256];


int RemoteSetDate()
{
	int err = NO_ERROR;

	time_t tim = time(NULL);
	struct tm *t = localtime(&tim);

	pTX_SETDATE ptx = (pTX_SETDATE)(cmdbuf);
	pRX_SETDATE prx = (pRX_SETDATE)(rspbuf);

	ptx->Func = FN_SETDATE;

	ptx->Year  = t->tm_year + 1900;		// dat->year;
	ptx->Month = t->tm_mon + 1;			// dat->month;
	ptx->Day   = t->tm_mday;			// dat->day;

	return (err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL));
}

int RemoteSetTime()
{
	int err = NO_ERROR;

	time_t tim = time(NULL);
	struct tm *t = localtime(&tim);

	pTX_SETTIME ptx = (pTX_SETTIME)(cmdbuf);
	pRX_SETTIME prx = (pRX_SETTIME)(rspbuf);

	ptx->Func = FN_SETTIME;

	ptx->Hours   = t->tm_hour;		// tim->hour;
	ptx->Minutes = t->tm_min;		// tim->minute;
	ptx->Seconds = t->tm_sec;		// tim->second;
	ptx->cSecs   = 0;				// tim->hsecond;

	return (err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL));
}

int RemoteOpen(char *name, int mode, int *handle)
{
	int err = NO_ERROR;

	pTX_FOPEN ptx = (pTX_FOPEN)(cmdbuf);
	pRX_FOPEN prx = (pRX_FOPEN)(rspbuf);

	ptx->Func = (BYTE)(FN_OPEN >> 8);
	ptx->Mode = (BYTE)mode;

	strcpy(ptx->Name, name);
	strupr(ptx->Name);

	err = ExchangeCmd(ptx, sizeof(*ptx) + strlen(name), prx, sizeof(rspbuf), NULL);
	if (!err) {
		*handle = prx->hFile;
	}

	return err;
}

int RemoteClose(int handle)
{
	int err = NO_ERROR;

	pTX_FCLOSE ptx = (pTX_FCLOSE)(cmdbuf);
	pRX_FCLOSE prx = (pRX_FCLOSE)(rspbuf);

	ptx->Func  = FN_CLOSE;
	ptx->hFile = handle;

	return (err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL));
}

int RemoteRead(int handle, void *buf, int cnt, int *n)
{
	int err = NO_ERROR;

	pTX_FREAD ptx = (pTX_FREAD)(cmdbuf);
	pRX_FREAD prx = (pRX_FREAD)(rspbuf);

	ptx->Func    = FN_READ;
	ptx->hFile   = handle;
	ptx->Bufsize = cnt;

	err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL);
	if (!err) {
		memcpy(buf, rspbuf + sizeof(*prx) - 1, prx->Count);
		*n = prx->Count;
	}

	return err;
}

int RemoteWrite(int handle, void *buf, int cnt, int *n)
{
	int err = NO_ERROR;

	pTX_FWRITE ptx = (pTX_FWRITE)(cmdbuf);
	pRX_FWRITE prx = (pRX_FWRITE)(rspbuf);

	ptx->Func    = FN_WRITE;
	ptx->hFile   = handle;
	ptx->Bufsize = cnt;

	memcpy(cmdbuf + sizeof(*ptx) - 1, buf, cnt);

	err = ExchangeCmd(ptx, sizeof(*ptx) - 1 + cnt, prx, sizeof(rspbuf), NULL);
	if (!err) {
		*n = prx->Count;
	}

	return err;
}

int RemoteDelete(char *name)
{
	int err = NO_ERROR;

	pTX_FDELETE ptx = (pTX_FDELETE)(cmdbuf);
	pRX_FDELETE prx = (pRX_FDELETE)(rspbuf);

	ptx->Func = FN_DELETE;
	strcpy(ptx->Name, name);
	strupr(ptx->Name);

	return (err = ExchangeCmd(ptx, sizeof(*ptx) + strlen(name), prx, sizeof(rspbuf), NULL));
}

long RemoteSeek(int handle, long pos, int mode)
{
	int err = NO_ERROR;

	pTX_FSEEK ptx = (pTX_FSEEK)(cmdbuf);
	pRX_FSEEK prx = (pRX_FSEEK)(rspbuf);

	ptx->Func   = (BYTE)(FN_SEEK >> 8);
	ptx->Method = (BYTE)mode;
	ptx->hFile  = handle;
	ptx->Offset = pos;

	err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL);
	return (err ? -1 : prx->Pos);
}

int RemoteFirst(char *fname, int attrib, pINFO info)
{
	int err = NO_ERROR;

	pTX_FIRST ptx = (pTX_FIRST)(cmdbuf);
	pRX_FIRST prx = (pRX_FIRST)(rspbuf);

	ptx->Func   = FN_FIRST;
	ptx->Attrib = attrib;

	strcpy(ptx->FName, fname);
	strupr(ptx->FName);

	err = ExchangeCmd(ptx, sizeof(*ptx) + strlen(fname), prx, sizeof(rspbuf), NULL);
	if (!err) {
		memcpy(info, prx->Reserved, sizeof(INFO));
	}

	return err;
}

int RemoteNext(pINFO info)
{
	int err = NO_ERROR;

	pTX_NEXT ptx = (pTX_NEXT)(cmdbuf);
	pRX_NEXT prx = (pRX_NEXT)(rspbuf);

	ptx->Filler = 0;
	ptx->Func  = FN_NEXT;
	memcpy(ptx->Reserved, info, sizeof(ptx->Reserved));

	err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL);
	if (!err) {
		memcpy(info, prx->Reserved, sizeof(INFO));
	}

	return err;
}

int RemoteRename(char *old, char *new)
{
	int err = NO_ERROR;

	pTX_FRENAME ptx = (pTX_FRENAME)(cmdbuf);
	pRX_FRENAME prx = (pRX_FRENAME)(rspbuf);

	ptx->Func = FN_RENAME;
	strncpy(ptx->OldName, old, sizeof(ptx->OldName));
	strncpy(ptx->NewName, new, sizeof(ptx->NewName));
	strupr(ptx->OldName);
	strupr(ptx->NewName);

	return (err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL));
}

int RemoteCreate(char *name, int attrib)
{
	int err = NO_ERROR;

	pTX_FCREATE ptx = (pTX_FCREATE)(cmdbuf);
	pRX_FCREATE prx = (pRX_FCREATE)(rspbuf);

	ptx->Func   = FN_CREATE;
	ptx->Size   = 0;
	ptx->Attrib = (BYTE)(attrib & 0xFF);
	strcpy(ptx->Name, name);
	strupr(ptx->Name);

	err = ExchangeCmd(ptx, sizeof(*ptx) + strlen(name), prx, sizeof(rspbuf), NULL);
	if (!err) {
		err = RemoteClose(prx->hFile);
	}

	return err;
}

int RemoteCommit(int handle)
{
	int err = NO_ERROR;

	pTX_FCOMMIT ptx = (pTX_FCOMMIT)(cmdbuf);
	pRX_FCOMMIT prx = (pRX_FCOMMIT)(rspbuf);

	ptx->Func  = FN_COMMIT;
	ptx->hFile = handle;

	return (err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL));
}

int RemoteConnect(long Project, long SubPrjct, int Access, int SrcDst)
{
	int err = NO_ERROR;

	pTX_CONNECT ptx = (pTX_CONNECT)(cmdbuf);
	pRX_CONNECT prx = (pRX_CONNECT)(rspbuf);

	ptx->Func      = CMD_CONNECT;
	ptx->ProjectNr = 77771; //3417; // Project;
	ptx->SubPrjct  = 0; // SubPrjct;
	ptx->Access    = 3; // Access;
	ptx->SrcDst    = 3; // SrcDst;

	err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL);
	if (err == 254) {
		err = RemoteConnect(prx->ProjectNr, prx->SubPrjct, prx->Access, prx->SrcDst);
	}

	return err;
}

int RemoteDisconnect()
{
	int err = NO_ERROR;

	pTX_DISCONNECT ptx = (pTX_DISCONNECT)(cmdbuf);
	pRX_DISCONNECT prx = (pRX_DISCONNECT)(rspbuf);

	ptx->Func = CMD_DISCONNECT;

	return (err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL));
}

int RemoteAbort()
{
	int err = NO_ERROR;

	pTX_ABORT ptx = (pTX_ABORT)(cmdbuf);
	pRX_ABORT prx = (pRX_ABORT)(rspbuf);

	ptx->Func = CMD_ABORT;

	return (err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(rspbuf), NULL));
}

long RemoteXCount(long Load)
{
	int err = NO_ERROR;

	pTX_XCOUNT ptx = (pTX_XCOUNT)(cmdbuf);
	pRX_XCOUNT prx = (pRX_XCOUNT)(rspbuf);

	ptx->Func  = CMD_XCOUNT;
	ptx->Count = Load;

	return ((err = ExchangeCmd(ptx, sizeof(*ptx), prx, sizeof(*prx), NULL)) ? -1 : prx->Count);
}
