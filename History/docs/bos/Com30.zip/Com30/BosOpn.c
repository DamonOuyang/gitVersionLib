#include "target.h"

typedef struct memfile {
	void *mem;
	size_t size;
} STORAGE;

static STORAGE files[16];


void FreeOpnStorage()
{
	int n, m;
    
	for (n = 0, m = sizeof(files) / sizeof(STORAGE); n < m; n++) {
		if (files[n].mem) {
			free(files[n].mem);
			memset(files + n, 0, sizeof(STORAGE));
		}
	}
}


static int getFile(char *name, STORAGE *storage)
{
	INFO info;
	BYTE rdbuf[200];
	int nread, count, space;

	int hremfil = -1;
	int err = NO_ERROR;

	if (storage->mem == NULL) {
		err = RemoteFirst(name, 0, &info);
		storage->size = info.size;
		storage->mem = malloc(storage->size);
		memset(storage->mem, 0, storage->size);
	}

	if (!err)
		err = RemoteOpen(name, CMPOPEN_RDONLY, &hremfil);
	
    for (count = 0, space = storage->size; !err; count += nread, space -= nread) {
		err = RemoteRead(hremfil, rdbuf, sizeof(rdbuf), &nread);
		if (nread && space >= nread) {
			memcpy((BYTE*)storage->mem + count, rdbuf, nread);
		}
		else break;
    }
    
	if (hremfil >= 0)
		RemoteClose(hremfil);

	return err;
}


static int getDir()
{
	return getFile("bosopn.dir", files + 0 );
}


static int getFiles()
{
	int err, n, m;
	pDIRENTRY pdir;
	
	pdir = files[0].mem;
	m = files[0].size / sizeof(DIRENTRY);

	if (m + 1 > sizeof(files) / sizeof(STORAGE))
		return SOME_ERROR;		// increase array length

	for (err = NO_ERROR, n = 1; n < m + 1 && !err; n++, pdir++) {
		err = getFile(pdir->Kind, files + n);
	}

	return err;
}


static void* getStorage(char *name, size_t *size)
{
	int n, m;
	pDIRENTRY pdir;
	
	pdir = files[0].mem;
	m = files[0].size / sizeof(DIRENTRY);

	if (m + 1 > sizeof(files) / sizeof(STORAGE))
		m = sizeof(files) / sizeof(STORAGE) - 1;

	for (n = 1; n < m + 1; n++, pdir++) {
		if (stricmp (name, pdir->Kind) == 0) {
			*size = files[n].size;
			return files[n].mem;
		}
	}

	return NULL;
}


void ShowOpnFiles()
{
	int n, ndir, nhdr, nomz, ntrn, nbtw, ncash, nakrt, npkrt, nkey;
    
	pDIRENTRY dir = (pDIRENTRY)files[0].mem;

	pOPNHDR  hdr  = (pOPNHDR) getStorage("OpnHdr.dat",  &nhdr);
	pOPNOMZ  omz  = (pOPNOMZ) getStorage("OpnOmz.dat",  &nomz);
	pOPNTRN  trn  = (pOPNTRN) getStorage("OpnTrn.dat",  &ntrn);
	pOPNBTW  btw  = (pOPNBTW) getStorage("OpnBtw.dat",  &nbtw);
	pOPNCASH cash = (pOPNCASH)getStorage("OpnCash.dat", &ncash);
//	pOPNAKRT akrt = (pOPNAKRT)getStorage("OpnAkrt.dat", &nakrt);
//	pOPNPKRT pkrt = (pOPNPKRT)getStorage("OpnPkrt.dat", &npkrt);
//	pOPNKEY  key  = (pOPNKEY) getStorage("OpnKey.dat",  &nkey);

	ndir = files[0].size / sizeof(DIRENTRY);
	for (n = 0; n < ndir; n++)
		dir++;

	nhdr  /= sizeof(OPNHDR);
	for (n = 0; n < nhdr; n++)
		hdr++;
	
	nomz  /= sizeof(OPNOMZ);
	for (n = 0; n < nomz; n++)
		omz++;

	ntrn  /= sizeof(OPNTRN);
	for (n = 0; n < ntrn; n++)
		trn++;
	
	nbtw  /= sizeof(OPNBTW);
	for (n = 0; n < nbtw; n++)
		btw++;

	ncash /= sizeof(OPNCASH);
	for (n = 0; n < ncash; n++)
		cash++;
}


int BosOpn(BOOL snapshot)
{
	int err = NO_ERROR;
	BOOL inSession = 0;
	long load;

	InitSession(ID_DCT, ID_ANY, TSK_BOSOPN);

	load = RemoteXCount(0);
	if (load < 0)
		load = RemoteXCount(0);

	err = (load < 0);

	if (!err)
		(err = RemoteSetDate()) || (err = RemoteSetTime()) || (err = RemoteConnect(0, 0, 0, 0));

	inSession = (err == NO_ERROR);
	memset(files, 0, sizeof(files));

	if (!err)
		(err = getDir()) || (err = getFiles());

	if (inSession) {
		if (snapshot || err)
			RemoteAbort();
		else RemoteDisconnect();
	}

	return err;
}
