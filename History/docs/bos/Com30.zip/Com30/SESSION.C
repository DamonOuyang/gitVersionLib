#include "target.h"

static SESSION ses;


// -------------------  Misc  -------------------------
BYTE make_checksum(void *src, int count)
{
  BYTE sum;
  BYTE *from = (BYTE *)src;
  
  sum = 0;
  while (count > 0) {
    sum ^= *from;
    sum  = (sum & 0x01) ? (sum >> 1) | 0x80 : (sum >> 1);
    from++; count--;
  }
  return (sum);
}


void bin_so(void *src, int count)
{
  BYTE *from = (BYTE *)src;
  
  for (; count > 0; count--, from++) {
    switch (*from) {
      case ESC_CHAR:    so(ESC_CHAR); so('0'); break;
      case START_CHAR:  so(ESC_CHAR); so('1'); break;
      case STOP_CHAR:   so(ESC_CHAR); so('2'); break;
      case START_CHAR2: so(ESC_CHAR); so('3'); break;
      case START_CHAR3: so(ESC_CHAR); so('4'); break;
      default:          so(*from);             break;
    }
  }
}


// -------------------  Transmit  -------------------------
static void tx_msg()
{
	MSG_HDR  msghdr;
	BYTE     chk2;

    msghdr.dst  = ses.dst;
    msghdr.src  = ses.src;
    msghdr.tsk  = ses.tsk;
    msghdr.typ  = ses.tx_type;
    msghdr.seq  = ses.seq;
    msghdr.len  = ses.tx_len;
    msghdr.chk1 = make_checksum(&msghdr, SIZ_HDR - 1);
    chk2        = make_checksum(ses.tx_data, ses.tx_len);

    so(START_CHAR);
    bin_so(&msghdr, SIZ_HDR);

    if (ses.tx_len) {
      bin_so(ses.tx_data, ses.tx_len);
      bin_so(&chk2, 1);
    }

	so(STOP_CHAR);
}


// -------------------  Receive  -------------------------
static pMSG_HDR rx_msg(BOOL restart)
{
	static BYTE buf[512];
	static BYTE *ptr;
	static int state;

	BYTE chr;

	if (restart) {
		memset(buf, 0, sizeof(buf));
		ptr = buf;
		state = 0;
	}

	while (count_si() > 0) {
		chr = si();

		if (chr == START_CHAR)
			state = 0;

		switch (state) {
			case 0:
				if (chr == START_CHAR) {
					memset(buf, 0, sizeof(buf));
					ptr = buf;
					state++;
				}
				break;

			case 1:
				if (chr == ESC_CHAR)
					state++;
				else if (chr == STOP_CHAR)
					return (pMSG_HDR)buf;
				else *ptr++ = chr;
				break;

			case 2:
				switch (chr) {
					case '0':  chr = ESC_CHAR;    break;
					case '1':  chr = START_CHAR;  break;
					case '2':  chr = STOP_CHAR;   break;
					case '3':  chr = START_CHAR2; break;
					case '4':  chr = START_CHAR3; break;
				}
				*ptr++ = chr;
				state--;
				break;
		}
	}

	return NULL;
}


// -------------------  Interface  -------------------------
void InitSession(long src, long dst, BYTE task) 
{
	memset(&ses, 0, sizeof(ses));

	ses.src = src;
	ses.dst = dst;
	ses.tsk = task;

	ses.cmd_timout = 50;	// 5 sec
	ses.cmd_retry = 2;
}


int ExchangeCmd(void *cmdbuf, int cmdlen, void *rspbuf, int rsplen, int *rspcount) 
{
	MSG_HDR *hdr;

	ses.tx_size = ses.tx_len = cmdlen;
	ses.tx_data = cmdbuf;
	ses.tx_type = PT_CMD;

	ses.rx_size = rsplen;
	ses.rx_len = 0;
	ses.rx_data = rspbuf;

	if (rspbuf)
		memset(rspbuf, 0, rsplen);

	if (rspcount)
		*rspcount = 0;

	ses.error = ERR_TIMOUT;
	ses.seq++;

	for (ses.retries = ses.cmd_retry; ses.retries >= 0; ses.retries--) {
		ses.timref = GetTimeElapsed();
		tx_msg();

		while (!TimeOut(ses.timref, ses.cmd_timout)) {
			hdr = rx_msg(1);
			
			while (!TimeOut(ses.timref, ses.cmd_timout) && hdr == NULL) {
				hdr = rx_msg(0);
			}
			
			if (hdr == NULL)
				break;		// time-out --> retry

			if (hdr->chk1 != make_checksum(hdr, SIZ_HDR - 1))
				continue;	// ignore msg

			if (hdr->tsk != ses.tsk)
				continue;	// ignore other tasknumbers

			if (hdr->typ == PT_CMD)
				continue;	// ignore commands received (loop echo)

			if (hdr->dst != ses.src)
				continue;	// ignore: not for us
			else if (ses.dst == ID_ANY)
				ses.dst = hdr->src;		// adjust destination from any to specific

			if (hdr->src != ses.dst)
				continue;	// ignore: not asked for

			if (hdr->typ == PT_ERR && hdr->seq == ses.seq) {	// error
				ses.error = hdr->len;
				ses.retries = 0;		// finished
				break;
			}

			if (hdr->typ == PT_RSP && hdr->seq == ses.seq) {	// rsp received

				pRX_PREFIX prx = (pRX_PREFIX)(hdr + 1);
				pTX_PREFIX ptx = (pTX_PREFIX)(ses.tx_data);

				if ((prx->Func & ptx->Func) != prx->Func)
					continue;	// not a matching response

				if (make_checksum(hdr + 1, hdr->len) != *((BYTE*)(hdr+1) + hdr->len))
					break;	// checksum error --> retry

				ses.rx_len = min(rsplen, hdr->len);
				
				if (rspcount)
					*rspcount = ses.rx_len;

				if (rspbuf)
					memcpy(rspbuf, hdr + 1, ses.rx_len);

				ses.error = ((pRX_PREFIX)(hdr + 1))->Error;
				ses.retries = 0;	// finished
				break;
			}
		}
	}

	return (ses.error);
}
