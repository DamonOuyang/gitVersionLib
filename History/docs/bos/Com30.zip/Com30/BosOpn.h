#ifndef bosopn_h

typedef struct direntry {
	char    Kind[16];      // Soort, filename enz. ASCIIZ string
	short   Version,       // Versienummer
			Compress,      // Datacompressie methode
			RecSize;       // Recordsize
	long    RecCount,      // Aantal records
			Pos,           // Offset in Data Area
			RcrdSpecial;   // Special Recordhandling bits
	char    reserved[14];   
} DIRENTRY;
typedef DIRENTRY *pDIRENTRY;

void FreeOpnStorage();
void ShowOpnFiles();
int BosOpn(BOOL snapshot);

#define bosopn_h
#endif

