#include "windows.h"
#include "stdio.h"



static HANDLE		port = INVALID_HANDLE_VALUE;

static DCB			dcb;
static COMSTAT		comstat;
static DWORD		comerror;
static WORD			outbufsiz;


static DCB DefaultDCB = {
    sizeof(DCB),			/* sizeof(DCB)							*/
    19200,					/* Baudrate at which running			*/
    1,						/* Binary Mode (skip EOF check)			*/
    1,						/* Enable parity checking				*/
    0,						/* CTS handshaking on output			*/
    0,						/* DSR handshaking on output			*/
    DTR_CONTROL_ENABLE,		/* DTR Flow control						*/
    0,						/* DSR Sensitivity						*/
    0,						/* Continue TX when Xoff sent			*/
    0,						/* Enable output X-ON/X-OFF				*/
    0,						/* Enable input X-ON/X-OFF				*/
    0,						/* Enable Err Replacement				*/
    0,						/* Enable Null stripping				*/
    RTS_CONTROL_DISABLE,	/* Rts Flow control						*/
    0,						/* Abort all reads and writes on Error	*/
    0,						/* Reserved								*/
    0,						/* Not currently used					*/
    0,						/* Transmit X-ON threshold				*/
    0,						/* Transmit X-OFF threshold				*/
    8,						/* Number of bits/byte, 4-8				*/
    0,						/* 0-4=None,Odd,Even,Mark,Space			*/
    0,						/* 0,1,2 = 1, 1.5, 2					*/
    0,						/* Tx and Rx X-ON character				*/
    0,						/* Tx and Rx X-OFF character			*/
    0,						/* Error replacement char				*/
    0,						/* End of Input character				*/
    0,						/* Received Event character				*/
    0						/* Fill for now.						*/
};


/*****************************************************************************
 * Open / Close / Flush / GetError                                           *
 *****************************************************************************/

int OpenComm(int Comx, long BaudRate, WORD wInQueue, WORD wOutQueue)
{
	int err = NO_ERROR;
	DCB dcb = DefaultDCB;

	char comname[32];

	sprintf(comname, "COM%d:", Comx);
	port = CreateFile(comname, GENERIC_READ | GENERIC_WRITE, 0, NULL, OPEN_EXISTING, 0, NULL);

	if (port != INVALID_HANDLE_VALUE) {
		dcb.BaudRate = BaudRate;

		SetupComm(port, wInQueue, wOutQueue);
		SetCommState(port, &dcb);

		outbufsiz = wOutQueue;
	}
	else err = GetLastError();

	return (err);
}


int CloseComm()
{
	if (port != INVALID_HANDLE_VALUE) {
		CloseHandle(port);
		port = INVALID_HANDLE_VALUE;
	}

	return (NO_ERROR);
}


int FlushComm(int nQueue)
{
	switch (nQueue) {
		case 0: FlushFileBuffers(port); break;
		case 1: PurgeComm(port, PURGE_RXABORT | PURGE_RXCLEAR); break;
	}
	
	return (NO_ERROR);
}


DWORD GetCommError(COMSTAT *ptr)
{
	ClearCommError(port, &comerror, &comstat);
	if (ptr)
		*ptr = comstat;

	return (comerror);
}


/*****************************************************************************
 * Comm IO                                                                   *
 *****************************************************************************/

DWORD ReadComm(void *buf, DWORD count)
{
	DWORD nread = 0;

	ReadFile(port, buf, count, &nread, NULL);
	return (nread);
}


DWORD WriteComm(void *buf, DWORD count)
{
	DWORD nwrit = 0;

	WriteFile(port, buf, count, &nwrit, NULL);
	return (nwrit);
}


int count_si(void)
{
	GetCommError(&comstat);
	return (comstat.cbInQue);
}


int space_so(void)
{
	GetCommError(&comstat);
	return (outbufsiz - comstat.cbOutQue);
}


BOOL empty_so(void)
{
	GetCommError(&comstat);
	return (comstat.cbOutQue == 0);
}


BYTE si(void)
{
	BYTE ch;

	ReadComm(&ch, 1);
	return (ch);
}


void so(BYTE chr)
{
	WriteComm(&chr, 1);
}


/***************************************************************************/
/*                                                                         */
/*  Timer procedures                                                       */
/*                                                                         */
/***************************************************************************/

DWORD GetTimeElapsed(void)
{
	return ((GetTickCount() + 50) / 100);
}


BOOL TimeOut(DWORD timeref, DWORD limit)
{
	return (GetTimeElapsed() - timeref > limit);
}


void Delay(DWORD n)
{
	Sleep(n * 100);
}
