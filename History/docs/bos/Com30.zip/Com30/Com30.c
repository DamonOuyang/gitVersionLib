// Com30.c : Defines the entry point for the console application.
//

#include "target.h"

int main(int argc, char* argv[])
{
	BOOL snapshot = 1;
	int err = OpenComm(1, 19200, 512, 512);

	if (!err) {

		err = BosOpn(snapshot);
		if (err == 5)	// Workaround for VMC locked file OpnHdr.dat after RemoteAbort()
			err = BosOpn(snapshot);

		CloseComm();

		if (!err)
			ShowOpnFiles();

		FreeOpnStorage();
	}

	return err;
}


